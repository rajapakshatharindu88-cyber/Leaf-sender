package com.leaf.share

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Emerald = Color(0xFF10B981)
val EmeraldDark = Color(0xFF047857)
val Forest = Color(0xFF064E3B)
val Mint = Color(0xFFECFDF5)
val MintLine = Color(0xFFD1FAE5)
val Ink = Color(0xFF0F2A20)
val Muted = Color(0xFF5B7A6C)
val Amber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFDC2626)

@Composable
fun LeafTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = EmeraldDark,
            onPrimary = Color.White,
            secondary = Emerald,
            background = Color.White,
            surface = Color.White,
            onSurface = Ink,
            primaryContainer = Mint,
            onPrimaryContainer = Forest,
            outline = MintLine
        ),
        content = content
    )
}

// ---- building blocks ------------------------------------------------------------------------

@Composable
fun LeafCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    var m = modifier
        .shadow(6.dp, shape, ambientColor = Emerald.copy(alpha = 0.18f), spotColor = Emerald.copy(alpha = 0.25f))
        .clip(shape)
        .background(Color.White)
        .border(1.dp, MintLine, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun SectionTitle(text: String, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Forest)
        trailing()
    }
}

@Composable
fun LeafButton(
    text: String,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = EmeraldDark,
            disabledContainerColor = MintLine,
            disabledContentColor = Muted
        )
    ) {
        if (icon != null) {
            Icon(icon, null, Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

@Composable
fun IconBubble(icon: ImageVector, tint: Color = EmeraldDark, size: Dp = 44.dp) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Mint),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun StatusDot(kind: StatusKind) {
    val color = when (kind) {
        StatusKind.IDLE -> Color(0xFF9CA3AF)
        StatusKind.READY -> Emerald
        StatusKind.BUSY -> Amber
        StatusKind.ERROR -> ErrorRed
    }
    val pulse = rememberInfiniteTransition(label = "pulse")
    val a by pulse.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulseAlpha"
    )
    val animated = kind == StatusKind.READY || kind == StatusKind.BUSY
    Box(
        Modifier
            .size(12.dp)
            .alpha(if (animated) a else 1f)
            .clip(CircleShape)
            .background(color)
    )
}

@Composable
fun ProgressCard(p: TransferProgress, onCancel: () -> Unit) {
    val f by animateFloatAsState(p.fraction, tween(300), label = "progress")
    LeafCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(if (p.direction == Direction.SEND) Icons.Filled.CallMade else Icons.Filled.CallReceived)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                val who = if (p.peerName.isBlank()) "" else (if (p.direction == Direction.SEND) " to " else " from ") + p.peerName
                Text(
                    (if (p.direction == Direction.SEND) "Sending" else "Receiving") + who,
                    fontWeight = FontWeight.SemiBold, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(p.status, color = Muted, fontSize = 13.sp)
            }
            TextButton(onClick = onCancel) { Text("Cancel", color = ErrorRed) }
        }
        Spacer(Modifier.height(12.dp))
        LinearProgressIndicator(
            progress = { f },
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp)),
            color = Emerald,
            trackColor = MintLine
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${(f * 100).toInt()}%", fontWeight = FontWeight.Bold, color = Forest)
            Text(formatSpeed(p.speedBps), fontWeight = FontWeight.SemiBold, color = EmeraldDark)
            Text(formatEta(p.etaSeconds), color = Muted)
        }
        if (p.currentFile.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(
                "File ${p.fileIndex} of ${p.fileCount}: ${p.currentFile}",
                color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Text(
            "${formatSize(p.doneBytes)} of ${formatSize(p.totalBytes)}",
            color = Muted, fontSize = 13.sp
        )
    }
}

@Composable
fun PeerRow(peer: Peer, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected) Mint else Color.White)
            .border(1.dp, if (selected) Emerald else MintLine, shape)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBubble(Icons.Filled.PhoneAndroid)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(peer.name, fontWeight = FontWeight.SemiBold, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(peer.transport.label, color = Muted, fontSize = 13.sp)
        }
        if (selected) Icon(Icons.Filled.CheckCircle, null, tint = Emerald)
    }
}

@Composable
fun HistoryRow(h: HistoryItem) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconBubble(
            if (h.outgoing) Icons.Filled.CallMade else Icons.Filled.CallReceived,
            tint = if (h.ok) EmeraldDark else ErrorRed
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(h.title, fontWeight = FontWeight.SemiBold, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(h.detail, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(formatTime(h.time), color = Muted, fontSize = 11.sp)
        }
        Icon(
            if (h.ok) Icons.Filled.CheckCircle else Icons.Filled.Error, null,
            tint = if (h.ok) Emerald else ErrorRed, modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun StorageCard() {
    val free = remember { Storage.freeBytes() }
    val total = remember { Storage.totalBytes() }
    val used = if (total > 0) ((total - free).toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
    LeafCard(Modifier.fillMaxWidth()) {
        Text("Storage", fontWeight = FontWeight.SemiBold, color = Forest)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { used },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = Emerald,
            trackColor = MintLine
        )
        Spacer(Modifier.height(8.dp))
        Text("${formatSize(free)} free of ${formatSize(total)}", color = Muted, fontSize = 13.sp)
        Text("Received files are saved in Downloads/LEAF", color = Muted, fontSize = 13.sp)
    }
}

// ---- screens --------------------------------------------------------------------------------

@Composable
fun HomeScreen(vm: LeafViewModel, onScan: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(painterResource(R.drawable.ic_leaf), null, tint = Emerald, modifier = Modifier.size(36.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "LEAF", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Forest,
                        fontFamily = FontFamily.SansSerif, letterSpacing = 3.sp
                    )
                    Text("Share files, nature's way", color = Muted, fontSize = 13.sp)
                }
                IconButton(onClick = { vm.go(Screen.SETTINGS) }) {
                    Icon(Icons.Filled.Settings, "Settings", tint = Forest)
                }
            }
        }
        item {
            LeafCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(vm.statusKind)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Connection", color = Muted, fontSize = 12.sp)
                        Text(vm.statusText, fontWeight = FontWeight.SemiBold, color = Ink)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ActionTile("SEND", Icons.AutoMirrored.Filled.Send, true, Modifier.weight(1f)) { vm.go(Screen.SEND) }
                ActionTile("RECEIVE", Icons.Filled.Download, false, Modifier.weight(1f)) { vm.go(Screen.RECEIVE) }
            }
        }
        if (vm.progress.active) {
            item { ProgressCard(vm.progress, vm::cancelTransfer) }
        }
        item {
            SectionTitle("Nearby devices") {
                IconButton(onClick = vm::refreshDiscovery) { Icon(Icons.Filled.Refresh, "Refresh", tint = EmeraldDark) }
            }
        }
        if (vm.peers.isEmpty()) {
            item {
                LeafCard(Modifier.fillMaxWidth()) {
                    Text("No devices found yet", fontWeight = FontWeight.SemiBold, color = Ink)
                    Text(
                        "Open LEAF on the other phone, tap RECEIVE, and keep both phones on the same Wi-Fi or hotspot.",
                        color = Muted, fontSize = 13.sp
                    )
                }
            }
        } else {
            items(vm.peers, key = { it.id }) { p ->
                PeerRow(p, selected = false) {
                    vm.selectedPeer = p
                    vm.codeInput = ""
                    vm.go(Screen.SEND)
                }
            }
        }
        item {
            LeafCard(Modifier.fillMaxWidth(), onClick = onScan) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Icons.Filled.QrCodeScanner)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Pair with QR code", fontWeight = FontWeight.SemiBold, color = Ink)
                        Text("Scan the code shown on the receiving phone", color = Muted, fontSize = 13.sp)
                    }
                }
            }
        }
        item { SectionTitle("Recent transfers") }
        if (vm.history.isEmpty()) {
            item { Text("Nothing yet. Your transfers will appear here.", color = Muted) }
        } else {
            items(vm.history.take(8)) { h -> HistoryRow(h) }
        }
        item { StorageCard() }
    }
}

@Composable
fun ActionTile(label: String, icon: ImageVector, primary: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    val bg = if (primary) Brush.linearGradient(listOf(Emerald, EmeraldDark)) else Brush.linearGradient(listOf(Mint, MintLine))
    val fg = if (primary) Color.White else Forest
    Box(
        modifier
            .height(132.dp)
            .shadow(10.dp, shape, ambientColor = Emerald.copy(alpha = 0.25f), spotColor = Emerald.copy(alpha = 0.35f))
            .clip(shape)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(18.dp)
    ) {
        Column(Modifier.align(Alignment.BottomStart)) {
            Icon(icon, null, tint = fg, modifier = Modifier.size(34.dp))
            Spacer(Modifier.height(8.dp))
            Text(label, color = fg, fontWeight = FontWeight.Bold, fontSize = 20.sp, letterSpacing = 1.5.sp)
        }
    }
}

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Forest) }
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Forest)
    }
}

@Composable
fun SendScreen(vm: LeafViewModel, onPickFiles: () -> Unit, onPickMedia: () -> Unit, onScan: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader("Send", vm::goHome)

        SectionTitle("1. Choose files")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = onPickFiles, modifier = Modifier.weight(1f).height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Filled.InsertDriveFile, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Files")
            }
            OutlinedButton(
                onClick = onPickMedia, modifier = Modifier.weight(1f).height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Filled.Image, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Photos & videos")
            }
        }
        if (vm.selectedFiles.isNotEmpty()) {
            LeafCard(Modifier.fillMaxWidth().animateContentSize()) {
                Text(
                    "${vm.selectedFiles.size} selected · ${formatSize(vm.selectedFiles.sumOf { it.size })}",
                    fontWeight = FontWeight.SemiBold, color = Forest
                )
                vm.selectedFiles.forEach { f ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Ink)
                            Text(formatSize(f.size), fontSize = 12.sp, color = Muted)
                        }
                        IconButton(onClick = { vm.removeFile(f) }) {
                            Icon(Icons.Filled.Close, "Remove", tint = Muted)
                        }
                    }
                }
            }
        }

        SectionTitle("2. Choose receiver") {
            IconButton(onClick = vm::refreshDiscovery) { Icon(Icons.Filled.Refresh, "Refresh", tint = EmeraldDark) }
        }
        val chosen = vm.selectedPeer
        val shown = if (chosen != null && vm.peers.none { it.id == chosen.id }) listOf(chosen) + vm.peers else vm.peers
        if (shown.isEmpty()) {
            Text(
                "No devices found. On the other phone open LEAF and tap RECEIVE, then pull to refresh here, or scan its QR code.",
                color = Muted, fontSize = 13.sp
            )
        }
        shown.forEach { p -> PeerRow(p, selected = chosen?.id == p.id) { vm.selectedPeer = p } }
        OutlinedButton(
            onClick = onScan, modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Filled.QrCodeScanner, null, Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Scan receiver's QR code")
        }

        SectionTitle("3. Enter the receiver's code")
        OutlinedTextField(
            value = vm.codeInput,
            onValueChange = { vm.codeInput = it.filter { c -> c.isDigit() }.take(6) },
            label = { Text("6-digit code") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        )

        if (vm.progress.active) {
            ProgressCard(vm.progress, vm::cancelTransfer)
        } else {
            LeafButton(
                "Send", Icons.AutoMirrored.Filled.Send,
                enabled = vm.selectedFiles.isNotEmpty() && vm.selectedPeer != null && vm.codeInput.length == 6
            ) { vm.send() }
        }
    }
}

@Composable
fun ReceiveScreen(vm: LeafViewModel) {
    LaunchedEffect(Unit) { vm.startReceiving() }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader("Receive", vm::goHome)
        LeafCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusDot(vm.statusKind)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(vm.statusText, fontWeight = FontWeight.SemiBold, color = Ink)
                    Text("Visible as \"${vm.deviceName}\"", color = Muted, fontSize = 13.sp)
                }
            }
        }
        LeafCard(Modifier.fillMaxWidth()) {
            Text("Your pairing code", color = Muted, fontSize = 13.sp)
            Text(
                vm.receiveCode.chunked(3).joinToString(" "),
                fontSize = 44.sp, fontWeight = FontWeight.Bold, color = EmeraldDark, letterSpacing = 4.sp
            )
            Text("Tell the sender this code, or let them scan the QR code below.", color = Muted, fontSize = 13.sp)
        }
        val bmp: ImageBitmap? = vm.qrBitmap?.asImageBitmap()
        AnimatedVisibility(visible = bmp != null, enter = fadeIn(tween(400))) {
            if (bmp != null) {
                Box(
                    Modifier
                        .size(240.dp)
                        .shadow(8.dp, RoundedCornerShape(24.dp), ambientColor = Emerald, spotColor = Emerald)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.White)
                        .padding(12.dp)
                ) {
                    Image(bmp, "QR code for pairing", Modifier.fillMaxSize())
                }
            }
        }
        if (vm.progress.active) ProgressCard(vm.progress, vm::cancelTransfer)
        OutlinedButton(
            onClick = vm::goHome, modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Stop receiving") }
        Text(
            "Keep this screen open while receiving. Both phones must be on the same Wi-Fi or hotspot (or use Wi-Fi Direct).",
            color = Muted, fontSize = 12.sp
        )
    }
}

@Composable
fun SettingsScreen(vm: LeafViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader("Settings", vm::goHome)
        OutlinedTextField(
            value = vm.deviceName,
            onValueChange = vm::renameDevice,
            label = { Text("Device name shown to others") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        )
        StorageCard()
        LeafCard(Modifier.fillMaxWidth()) {
            Text("How LEAF connects", fontWeight = FontWeight.SemiBold, color = Forest)
            Spacer(Modifier.height(6.dp))
            Text(
                "• Same Wi-Fi or hotspot: automatic discovery, usually the fastest option.\n" +
                    "• Wi-Fi Direct: works without a router; Android asks the receiver to accept an invitation.\n" +
                    "• Everything is encrypted (AES-256-GCM) with a key made from the 6-digit code, and every file is verified with SHA-256.\n" +
                    "• Speeds are measured live; real speed depends on both phones and the Wi-Fi.",
                color = Muted, fontSize = 13.sp
            )
        }
        Text("LEAF 1.0.0 · No internet or account needed", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun LeafApp(
    vm: LeafViewModel,
    onPickFiles: () -> Unit,
    onPickMedia: () -> Unit,
    onScan: () -> Unit
) {
    val snack = remember { SnackbarHostState() }
    val view = LocalView.current
    val keepOn = vm.progress.active || vm.receiving
    DisposableEffect(keepOn) {
        view.keepScreenOn = keepOn
        onDispose { view.keepScreenOn = false }
    }
    BackHandler(enabled = vm.screen != Screen.HOME) { vm.goHome() }
    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            snack.showSnackbar(m)
            vm.message = null
        }
    }

    val offer = vm.offer
    if (offer != null) {
        AlertDialog(
            onDismissRequest = { vm.respondOffer(false) },
            shape = RoundedCornerShape(24.dp),
            containerColor = Color.White,
            title = { Text("Accept files from ${offer.senderName}?", color = Forest, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("${offer.files.size} file(s) · ${formatSize(offer.totalBytes)}", color = Muted)
                    Spacer(Modifier.height(8.dp))
                    offer.files.take(6).forEach {
                        Text("• ${it.name} (${formatSize(it.size)})", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Ink)
                    }
                    if (offer.files.size > 6) Text("… and ${offer.files.size - 6} more", color = Muted)
                }
            },
            confirmButton = { TextButton(onClick = { vm.respondOffer(true) }) { Text("Accept", color = EmeraldDark, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { vm.respondOffer(false) }) { Text("Decline", color = ErrorRed) } }
        )
    }

    Scaffold(
        containerColor = Color.White,
        snackbarHost = { SnackbarHost(snack) }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            AnimatedContent(
                targetState = vm.screen,
                transitionSpec = {
                    (fadeIn(tween(240)) + slideInHorizontally(tween(260)) { it / 10 }) togetherWith fadeOut(tween(140))
                },
                label = "screens"
            ) { s ->
                when (s) {
                    Screen.HOME -> HomeScreen(vm, onScan)
                    Screen.SEND -> SendScreen(vm, onPickFiles, onPickMedia, onScan)
                    Screen.RECEIVE -> ReceiveScreen(vm)
                    Screen.SETTINGS -> SettingsScreen(vm)
                }
            }
        }
    }
}
