package com.leaf.share

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketException
import java.net.SocketTimeoutException
import java.security.MessageDigest
import java.security.SecureRandom

/** Lets the UI abort a running transfer from any thread. */
class Canceller {
    @Volatile
    var cancelled = false

    @Volatile
    var socket: Socket? = null

    fun cancel() {
        cancelled = true
        try {
            socket?.close()
        } catch (_: Exception) {
        }
    }
}

/** Measures real throughput (smoothed) and remaining time. */
class Meter(
    private val total: Long,
    private val onUpdate: (done: Long, speedBps: Double, etaSeconds: Long) -> Unit
) {
    private val start = System.nanoTime()
    private var done = 0L
    private var lastT = start
    private var lastDone = 0L
    private var speed = 0.0

    fun add(n: Long) {
        done += n
        tick(false)
    }

    fun finish() = tick(true)

    private fun tick(force: Boolean) {
        val now = System.nanoTime()
        val dt = (now - lastT) / 1e9
        if (dt >= 0.25 || (force && dt > 0.02)) {
            val inst = (done - lastDone) / dt
            speed = if (speed == 0.0) inst else speed * 0.6 + inst * 0.4
            lastT = now
            lastDone = done
        }
        if (dt >= 0.25 || force) {
            val eta = if (speed > 1.0) ((total - done) / speed).toLong() else -1L
            onUpdate(done, speed, eta)
        }
    }

    fun averageBps(): Double {
        val secs = (System.nanoTime() - start) / 1e9
        return if (secs > 0.001) done / secs else 0.0
    }

    val bytes: Long get() = done
}

private fun newSalt(): ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }

private val CLIENT_TO_SERVER = byteArrayOf(1, 0, 0, 0)
private val SERVER_TO_CLIENT = byteArrayOf(2, 0, 0, 0)

private const val IO_BUFFER = 256 * 1024
private const val MAX_FILES = 5000
private const val MAX_FILE_SIZE = 2L * 1024 * 1024 * 1024 * 1024 // 2 TB sanity limit

/**
 * Sender side. Blocking: call it from a background thread.
 *
 * Protocol (everything after the two salts is AES-256-GCM encrypted with a key derived from the
 * 6-digit pairing code):
 *   client salt(16) -> | <- server salt(16)
 *   hello: "LEAF1", device name, file count, [name, size]...
 *   receiver replies one byte: 1 = accepted, 0 = declined, 2 = not enough storage
 *   per file: raw bytes, then SHA-256(32); receiver replies 1 byte: 1 = verified, 0 = mismatch
 */
fun sendFiles(
    ctx: Context,
    hosts: List<String>,
    port: Int,
    code: String,
    deviceName: String,
    files: List<OutgoingFile>,
    attempts: Int,
    cancel: Canceller,
    onProgress: (TransferProgress) -> Unit
): TransferOutcome {
    val total = files.sumOf { it.size }
    var socket: Socket? = null
    var meterRef: Meter? = null
    try {
        onProgress(
            TransferProgress(
                active = true, direction = Direction.SEND, fileCount = files.size,
                totalBytes = total, status = "Connecting…"
            )
        )
        var lastErr: Exception? = null
        outer@ for (attempt in 1..attempts) {
            for (h in hosts) {
                if (cancel.cancelled) break@outer
                val s = Socket()
                cancel.socket = s
                try {
                    s.connect(InetSocketAddress(h, port), 3000)
                    socket = s
                    break@outer
                } catch (e: Exception) {
                    lastErr = e
                    try {
                        s.close()
                    } catch (_: Exception) {
                    }
                }
            }
            if (attempt < attempts) Thread.sleep(1500)
        }
        if (cancel.cancelled) return TransferOutcome(false, "Cancelled")
        val sock = socket ?: return TransferOutcome(
            false,
            "Could not reach the receiver (${lastErr?.javaClass?.simpleName ?: "no route"}). " +
                "Make sure both phones are on the same Wi-Fi/hotspot and the receiver is on the Receive screen."
        )
        sock.tcpNoDelay = true
        try {
            sock.sendBufferSize = 1 shl 20
            sock.receiveBufferSize = 1 shl 20
        } catch (_: Exception) {
        }
        sock.soTimeout = 90_000

        val rawOut = sock.getOutputStream()
        val rawIn = sock.getInputStream()
        val clientSalt = newSalt()
        rawOut.write(clientSalt)
        rawOut.flush()
        val serverSalt = ByteArray(16)
        DataInputStream(rawIn).readFully(serverSalt)
        val key = Crypto.deriveKey(code, clientSalt + serverSalt)
        val out = DataOutputStream(GcmOutputStream(rawOut, key, CLIENT_TO_SERVER))
        val inp = DataInputStream(GcmInputStream(BufferedInputStream(rawIn, 64 * 1024), key, SERVER_TO_CLIENT))

        out.writeUTF(LEAF_MAGIC)
        out.writeUTF(deviceName)
        out.writeInt(files.size)
        for (f in files) {
            out.writeUTF(f.name)
            out.writeLong(f.size)
        }
        out.flush()

        onProgress(
            TransferProgress(
                active = true, direction = Direction.SEND, fileCount = files.size,
                totalBytes = total, status = "Waiting for the receiver to accept…"
            )
        )
        when (inp.readUnsignedByte()) {
            1 -> Unit
            2 -> return TransferOutcome(false, "The receiver does not have enough free storage.")
            else -> return TransferOutcome(false, "The receiver declined the files.")
        }
        sock.soTimeout = 30_000

        var currentIndex = 0
        var currentName = ""
        val meter = Meter(total) { done, speed, eta ->
            onProgress(
                TransferProgress(
                    active = true, direction = Direction.SEND, currentFile = currentName,
                    fileIndex = currentIndex + 1, fileCount = files.size, doneBytes = done,
                    totalBytes = total, speedBps = speed, etaSeconds = eta, status = "Sending"
                )
            )
        }
        meterRef = meter
        val buf = ByteArray(IO_BUFFER)
        val failed = ArrayList<String>()
        for ((i, f) in files.withIndex()) {
            currentIndex = i
            currentName = f.name
            val md = MessageDigest.getInstance("SHA-256")
            val stream = ctx.contentResolver.openInputStream(f.uri)
                ?: throw IOException("Cannot read ${f.name}")
            stream.use { ins ->
                var remaining = f.size
                while (remaining > 0) {
                    if (cancel.cancelled) throw SocketException("cancelled")
                    val r = ins.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                    if (r < 0) throw IOException("${f.name} changed while sending")
                    md.update(buf, 0, r)
                    out.write(buf, 0, r)
                    remaining -= r
                    meter.add(r.toLong())
                }
            }
            out.write(md.digest())
            out.flush()
            if (inp.readUnsignedByte() != 1) failed.add(f.name)
        }
        meter.finish()
        val avg = meter.averageBps()
        return if (failed.isEmpty()) {
            TransferOutcome(
                true, "Sent ${files.size} file(s), ${formatSize(total)} at ${formatSpeed(avg)} average. All verified.",
                total, avg, files.map { it.name }
            )
        } else {
            TransferOutcome(false, "Integrity check failed for: ${failed.joinToString()}", meter.bytes, avg, files.map { it.name })
        }
    } catch (e: AuthException) {
        return TransferOutcome(false, "Pairing failed. Check the 6-digit code shown on the receiver.", authFailed = true)
    } catch (e: Exception) {
        if (cancel.cancelled) return TransferOutcome(false, "Transfer cancelled.", meterRef?.bytes ?: 0)
        val msg = when (e) {
            is EOFException, is SocketException ->
                "Connection closed. The code may be wrong, or the receiver stopped or declined."
            is SocketTimeoutException -> "The receiver stopped responding."
            else -> e.message ?: "Transfer failed."
        }
        return TransferOutcome(false, msg, meterRef?.bytes ?: 0)
    } finally {
        try {
            socket?.close()
        } catch (_: Exception) {
        }
    }
}

/**
 * Receiver side for one connection. Suspends while the user decides whether to accept.
 * [askUser] must return true to accept the offered files.
 */
suspend fun receiveSession(
    ctx: Context,
    socket: Socket,
    code: String,
    deviceName: String,
    cancel: Canceller,
    askUser: suspend (IncomingOffer) -> Boolean,
    onProgress: (TransferProgress) -> Unit
): TransferOutcome {
    var meterRef: Meter? = null
    var pending: Storage.Incoming? = null
    try {
        socket.tcpNoDelay = true
        try {
            socket.receiveBufferSize = 1 shl 20
            socket.sendBufferSize = 1 shl 20
        } catch (_: Exception) {
        }
        socket.soTimeout = 15_000
        val rawIn = socket.getInputStream()
        val rawOut = socket.getOutputStream()
        val clientSalt = ByteArray(16)
        DataInputStream(rawIn).readFully(clientSalt)
        val serverSalt = newSalt()
        rawOut.write(serverSalt)
        rawOut.flush()
        val key = Crypto.deriveKey(code, clientSalt + serverSalt)
        val inp = DataInputStream(GcmInputStream(BufferedInputStream(rawIn, 64 * 1024), key, CLIENT_TO_SERVER))
        val out = DataOutputStream(GcmOutputStream(rawOut, key, SERVER_TO_CLIENT))

        // A wrong code makes this first read throw AuthException.
        if (inp.readUTF() != LEAF_MAGIC) throw IOException("Not a LEAF connection")
        val senderName = inp.readUTF().take(60)
        val count = inp.readInt()
        if (count < 1 || count > MAX_FILES) throw IOException("Invalid file count")
        val metas = ArrayList<FileMeta>()
        for (i in 0 until count) {
            val name = sanitizeName(inp.readUTF())
            val size = inp.readLong()
            if (size < 0 || size > MAX_FILE_SIZE) throw IOException("Invalid file size")
            metas.add(FileMeta(name, size))
        }
        val offer = IncomingOffer(senderName, metas)
        val total = offer.totalBytes

        if (total > Storage.freeBytes()) {
            out.writeByte(2)
            out.flush()
            return TransferOutcome(false, "Declined: not enough free storage for ${formatSize(total)}.")
        }
        onProgress(
            TransferProgress(
                active = true, direction = Direction.RECEIVE, peerName = senderName,
                fileCount = count, totalBytes = total, status = "Waiting for your confirmation…"
            )
        )
        val accepted = askUser(offer)
        if (!accepted) {
            out.writeByte(0)
            out.flush()
            return TransferOutcome(false, "You declined the files from $senderName.")
        }
        out.writeByte(1)
        out.flush()
        socket.soTimeout = 30_000

        var currentIndex = 0
        var currentName = ""
        val meter = Meter(total) { done, speed, eta ->
            onProgress(
                TransferProgress(
                    active = true, direction = Direction.RECEIVE, peerName = senderName,
                    currentFile = currentName, fileIndex = currentIndex + 1, fileCount = count,
                    doneBytes = done, totalBytes = total, speedBps = speed, etaSeconds = eta,
                    status = "Receiving"
                )
            )
        }
        meterRef = meter
        val buf = ByteArray(IO_BUFFER)
        val failed = ArrayList<String>()
        for ((i, m) in metas.withIndex()) {
            currentIndex = i
            currentName = m.name
            val md = MessageDigest.getInstance("SHA-256")
            val target = Storage.openIncoming(ctx, m.name)
            pending = target
            target.stream.use { os ->
                var remaining = m.size
                while (remaining > 0) {
                    if (cancel.cancelled) throw SocketException("cancelled")
                    val r = inp.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                    if (r < 0) throw EOFException()
                    md.update(buf, 0, r)
                    os.write(buf, 0, r)
                    remaining -= r
                    meter.add(r.toLong())
                }
            }
            val expected = ByteArray(32)
            inp.readFully(expected)
            val ok = MessageDigest.isEqual(md.digest(), expected)
            if (ok) {
                Storage.commit(ctx, target.uri)
            } else {
                Storage.discard(ctx, target.uri)
                failed.add(m.name)
            }
            pending = null
            out.writeByte(if (ok) 1 else 0)
            out.flush()
        }
        meter.finish()
        val avg = meter.averageBps()
        return if (failed.isEmpty()) {
            TransferOutcome(
                true,
                "Received ${count} file(s), ${formatSize(total)} from $senderName at ${formatSpeed(avg)} average. All verified. Saved in Downloads/LEAF.",
                total, avg, metas.map { it.name }
            )
        } else {
            TransferOutcome(false, "Integrity check failed for: ${failed.joinToString()}", meter.bytes, avg, metas.map { it.name })
        }
    } catch (e: AuthException) {
        return TransferOutcome(false, "Someone tried to connect with a wrong code.", authFailed = true)
    } catch (e: Exception) {
        pending?.let { Storage.discard(ctx, it.uri) }
        if (cancel.cancelled) return TransferOutcome(false, "Transfer cancelled.", meterRef?.bytes ?: 0)
        val msg = when (e) {
            is EOFException, is SocketException -> "The sender disconnected before the transfer finished."
            is SocketTimeoutException -> "The sender stopped responding."
            else -> e.message ?: "Receiving failed."
        }
        return TransferOutcome(false, msg, meterRef?.bytes ?: 0)
    } finally {
        try {
            socket.close()
        } catch (_: Exception) {
        }
    }
}

/** Reads display name and size of a picked document. Returns null if the size is unknown. */
fun describeUri(ctx: Context, uri: Uri): OutgoingFile? {
    var name = "file"
    var size = -1L
    try {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(android.provider.OpenableColumns.SIZE)
                if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        if (size < 0) {
            ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { size = it.length }
        }
    } catch (_: Exception) {
    }
    if (size < 0) return null
    return OutgoingFile(uri, sanitizeName(name), size)
}
