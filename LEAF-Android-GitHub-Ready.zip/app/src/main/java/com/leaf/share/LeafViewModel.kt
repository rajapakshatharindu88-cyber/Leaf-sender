package com.leaf.share

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.security.SecureRandom

class LeafViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>()
    private val prefs = app.getSharedPreferences("leaf", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())

    var screen by mutableStateOf(Screen.HOME)
    var deviceName by mutableStateOf(prefs.getString("name", null) ?: defaultName())
        private set
    var lanPeers by mutableStateOf(listOf<Peer>())
        private set
    var directPeers by mutableStateOf(listOf<Peer>())
        private set
    var selectedFiles by mutableStateOf(listOf<OutgoingFile>())
        private set
    var selectedPeer by mutableStateOf<Peer?>(null)
    var codeInput by mutableStateOf("")
    var receiving by mutableStateOf(false)
        private set
    var receiveCode by mutableStateOf("")
        private set
    var qrBitmap by mutableStateOf<Bitmap?>(null)
        private set
    var progress by mutableStateOf(TransferProgress())
        private set
    var offer by mutableStateOf<IncomingOffer?>(null)
        private set
    var history by mutableStateOf(History.load(prefs))
        private set
    var message by mutableStateOf<String?>(null)
    var statusText by mutableStateOf("Idle — choose Send or Receive")
        private set
    var statusKind by mutableStateOf(StatusKind.IDLE)
        private set
    var directAllowed by mutableStateOf(false)

    val peers: List<Peer> get() = lanPeers + directPeers

    private var lan: LanDiscovery? = null
    private var direct: WifiDirect? = null
    private var server: ServerSocket? = null
    private var currentCancel: Canceller? = null
    private var decision: CompletableDeferred<Boolean>? = null
    private var pendingDirect: Pair<Peer, String>? = null

    @Volatile
    private var serverCode = ""

    @Volatile
    private var serverPort = LEAF_PORT
    private var failedAttempts = 0

    private fun defaultName(): String {
        val n = try {
            Settings.Global.getString(getApplication<Application>().contentResolver, "device_name")
        } catch (_: Exception) {
            null
        }
        return (n?.takeIf { it.isNotBlank() } ?: Build.MODEL).take(40)
    }

    private fun post(block: () -> Unit) {
        main.post(block)
    }

    private fun setStatus(kind: StatusKind, text: String) {
        statusKind = kind
        statusText = text
    }

    // ---- navigation -------------------------------------------------------------------------

    fun go(s: Screen) {
        if (screen == Screen.RECEIVE && s != Screen.RECEIVE) stopReceiving()
        screen = s
    }

    fun goHome() = go(Screen.HOME)

    fun renameDevice(n: String) {
        val clean = n.take(40)
        deviceName = clean
        prefs.edit().putString("name", clean).apply()
    }

    // ---- discovery --------------------------------------------------------------------------

    fun startDiscovery() {
        if (lan == null) lan = LanDiscovery(ctx) { list -> post { lanPeers = list } }
        lan?.startDiscovery()
        if (directAllowed) {
            val d = ensureDirect()
            d?.discover()
        }
    }

    fun refreshDiscovery() {
        lan?.restartDiscovery()
        if (lan == null) startDiscovery()
        if (directAllowed) ensureDirect()?.discover()
    }

    private fun ensureDirect(): WifiDirect? {
        if (!directAllowed) return null
        var d = direct
        if (d == null) {
            d = WifiDirect(
                ctx,
                onPeers = { list -> post { directPeers = list } },
                onConnected = { ip, isOwner -> post { onDirectConnected(ip, isOwner) } },
                onStatus = { text -> post { message = text } }
            )
            if (!d.supported) return null
            direct = d
        }
        d.start()
        return d
    }

    // ---- receiving --------------------------------------------------------------------------

    fun startReceiving() {
        if (receiving) return
        receiving = true
        failedAttempts = 0
        newCode()
        setStatus(StatusKind.READY, "Ready to receive")
        viewModelScope.launch(Dispatchers.IO) { runServer() }
        if (directAllowed) ensureDirect()?.hostGroup()
        post { refreshQrLater() }
    }

    private fun newCode() {
        val c = (100000 + SecureRandom().nextInt(900000)).toString()
        serverCode = c
        receiveCode = c
        refreshQr()
    }

    private fun refreshQrLater() {
        main.postDelayed({ if (receiving) refreshQr() }, 3500)
    }

    private fun refreshQr() {
        val hosts = LocalNet.ipv4Hosts().take(4)
        val text = "leaf://pair?h=" + hosts.joinToString(",") + "&p=" + serverPort +
            "&c=" + serverCode + "&n=" + Uri.encode(deviceName)
        qrBitmap = try {
            makeQr(text)
        } catch (_: Exception) {
            null
        }
    }

    private fun makeQr(text: String): Bitmap {
        val size = 640
        val matrix = QRCodeWriter().encode(
            text, BarcodeFormat.QR_CODE, size, size, mapOf(EncodeHintType.MARGIN to 1)
        )
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val dark = Color.parseColor("#064E3B")
        for (x in 0 until size) {
            for (y in 0 until size) {
                bmp.setPixel(x, y, if (matrix.get(x, y)) dark else Color.WHITE)
            }
        }
        return bmp
    }

    private suspend fun runServer() {
        val ss: ServerSocket = try {
            ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(LEAF_PORT))
            }
        } catch (_: Exception) {
            try {
                ServerSocket(0)
            } catch (_: Exception) {
                post {
                    message = "Could not open a receiving port."
                    receiving = false
                    setStatus(StatusKind.ERROR, "Receiver could not start")
                }
                return
            }
        }
        server = ss
        serverPort = ss.localPort
        post {
            if (lan == null) lan = LanDiscovery(ctx) { list -> post { lanPeers = list } }
            lan?.register(deviceName, serverPort)
            refreshQr()
        }
        while (!ss.isClosed) {
            val s = try {
                ss.accept()
            } catch (_: Exception) {
                break
            }
            handleIncoming(s)
        }
    }

    private suspend fun handleIncoming(s: java.net.Socket) {
        val cancel = Canceller()
        cancel.socket = s
        currentCancel = cancel
        post { setStatus(StatusKind.BUSY, "Connected — incoming transfer") }
        val result = receiveSession(
            ctx, s, serverCode, deviceName, cancel,
            askUser = { o -> askUser(o) },
            onProgress = { p -> post { progress = p } }
        )
        currentCancel = null
        post {
            progress = TransferProgress()
            if (result.authFailed) {
                failedAttempts++
                if (failedAttempts >= 5) {
                    failedAttempts = 0
                    newCode()
                    message = "Too many wrong codes. A new code was generated."
                } else {
                    message = result.message
                }
            } else {
                if (result.names.isNotEmpty()) {
                    addHistory(
                        title = if (result.names.size == 1) result.names[0] else "${result.names.size} files",
                        detail = result.message,
                        outgoing = false,
                        ok = result.success
                    )
                }
                message = result.message
            }
            if (receiving) setStatus(StatusKind.READY, "Ready to receive") else setStatus(StatusKind.IDLE, "Idle")
        }
    }

    private suspend fun askUser(o: IncomingOffer): Boolean {
        val d = CompletableDeferred<Boolean>()
        decision = d
        post { offer = o }
        val r = withTimeoutOrNull(60_000) { d.await() } ?: false
        post { offer = null }
        return r
    }

    fun respondOffer(accept: Boolean) {
        decision?.complete(accept)
    }

    fun stopReceiving() {
        receiving = false
        decision?.complete(false)
        currentCancel?.cancel()
        try {
            server?.close()
        } catch (_: Exception) {
        }
        server = null
        lan?.unregister()
        direct?.stopGroup()
        qrBitmap = null
        offer = null
        if (!progress.active) setStatus(StatusKind.IDLE, "Idle — choose Send or Receive")
    }

    // ---- sending ----------------------------------------------------------------------------

    fun addFiles(uris: List<Uri>) {
        val current = selectedFiles.toMutableList()
        var skipped = 0
        for (u in uris) {
            if (current.any { it.uri == u }) continue
            val f = describeUri(ctx, u)
            if (f == null) skipped++ else current.add(f)
        }
        selectedFiles = current
        if (skipped > 0) message = "$skipped item(s) skipped: size could not be read."
    }

    fun removeFile(f: OutgoingFile) {
        selectedFiles = selectedFiles.filter { it != f }
    }

    fun send() {
        val peer = selectedPeer
        val code = codeInput
        if (progress.active) return
        if (selectedFiles.isEmpty()) {
            message = "Choose at least one file first."
            return
        }
        if (peer == null) {
            message = "Choose a receiving device first."
            return
        }
        if (code.length != 6) {
            message = "Enter the 6-digit code shown on the receiver."
            return
        }
        if (peer.transport == Transport.WIFI_DIRECT) {
            startDirectSend(peer, code)
        } else {
            runSend(peer.hosts, peer.port, peer.name, code, 1)
        }
    }

    private fun startDirectSend(peer: Peer, code: String) {
        val d = ensureDirect()
        if (d == null) {
            message = "Wi-Fi Direct is not available. Grant the permission and try again."
            return
        }
        pendingDirect = peer to code
        progress = TransferProgress(
            active = true, direction = Direction.SEND, peerName = peer.name,
            status = "Joining Wi-Fi Direct group — accept the invitation on the other phone"
        )
        setStatus(StatusKind.BUSY, "Connecting via Wi-Fi Direct")
        d.connect(peer) { reason ->
            post {
                pendingDirect = null
                progress = TransferProgress()
                setStatus(StatusKind.ERROR, "Wi-Fi Direct connection failed")
                message = "Wi-Fi Direct connection failed (code $reason)."
            }
        }
    }

    private fun onDirectConnected(groupOwnerIp: String?, isGroupOwner: Boolean) {
        val pd = pendingDirect
        if (pd != null) {
            pendingDirect = null
            if (isGroupOwner || groupOwnerIp == null) {
                progress = TransferProgress()
                setStatus(StatusKind.ERROR, "Wi-Fi Direct role conflict")
                message = "Wi-Fi Direct connected, but this phone became the group owner and the " +
                    "receiver's address is unknown. Use the Wi-Fi network / QR option instead."
            } else {
                runSend(listOf(groupOwnerIp), LEAF_PORT, pd.first.name, pd.second, 4)
            }
        } else if (receiving) {
            refreshQr()
        }
    }

    private fun runSend(hosts: List<String>, port: Int, peerName: String, code: String, attempts: Int) {
        val cancel = Canceller()
        currentCancel = cancel
        val files = selectedFiles
        progress = TransferProgress(
            active = true, direction = Direction.SEND, peerName = peerName,
            fileCount = files.size, totalBytes = files.sumOf { it.size }, status = "Connecting…"
        )
        setStatus(StatusKind.BUSY, "Connecting to $peerName")
        viewModelScope.launch(Dispatchers.IO) {
            val outcome = sendFiles(ctx, hosts, port, code, deviceName, files, attempts, cancel) { p ->
                post { progress = p.copy(peerName = peerName) }
            }
            post {
                currentCancel = null
                progress = TransferProgress()
                message = outcome.message
                if (outcome.authFailed) {
                    setStatus(StatusKind.ERROR, "Wrong pairing code")
                } else {
                    setStatus(
                        if (outcome.success) StatusKind.IDLE else StatusKind.ERROR,
                        if (outcome.success) "Transfer complete" else "Transfer did not finish"
                    )
                    addHistory(
                        title = if (files.size == 1) files[0].name else "${files.size} files",
                        detail = outcome.message,
                        outgoing = true,
                        ok = outcome.success
                    )
                    if (outcome.success) {
                        selectedFiles = emptyList()
                        codeInput = ""
                    }
                }
            }
        }
    }

    fun cancelTransfer() {
        currentCancel?.cancel()
        if (pendingDirect != null) {
            pendingDirect = null
            direct?.cancelConnect()
            progress = TransferProgress()
            setStatus(StatusKind.IDLE, "Cancelled")
        }
    }

    // ---- QR pairing -------------------------------------------------------------------------

    fun onQrScanned(raw: String) {
        try {
            val uri = Uri.parse(raw)
            if (uri.scheme != "leaf" || uri.host != "pair") {
                message = "That QR code is not a LEAF pairing code."
                return
            }
            val hosts = (uri.getQueryParameter("h") ?: "").split(",")
                .filter { Regex("""\d{1,3}(\.\d{1,3}){3}""").matches(it) }
                .take(4)
            val port = uri.getQueryParameter("p")?.toIntOrNull() ?: 0
            val c = uri.getQueryParameter("c") ?: ""
            val name = (uri.getQueryParameter("n") ?: "Receiver").take(40)
            if (hosts.isEmpty() || port !in 1..65535 || !Regex("""\d{6}""").matches(c)) {
                message = "That QR code is not valid."
                return
            }
            selectedPeer = Peer("qr:$name", name, hosts, port, Transport.LAN)
            codeInput = c
            go(Screen.SEND)
            message = "Paired with $name. Choose files and tap Send."
        } catch (_: Exception) {
            message = "Could not read that QR code."
        }
    }

    // ---- history ----------------------------------------------------------------------------

    private fun addHistory(title: String, detail: String, outgoing: Boolean, ok: Boolean) {
        history = (listOf(HistoryItem(title, detail, outgoing, ok, System.currentTimeMillis())) + history).take(30)
        History.save(prefs, history)
    }

    override fun onCleared() {
        super.onCleared()
        try {
            server?.close()
        } catch (_: Exception) {
        }
        lan?.shutdown()
        direct?.shutdown()
    }
}
