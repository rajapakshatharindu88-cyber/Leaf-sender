package com.leaf.share

import java.io.DataInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.security.GeneralSecurityException
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Thrown when decryption fails, which almost always means the pairing code was wrong. */
class AuthException(message: String) : IOException(message)

object Crypto {
    const val CHUNK = 64 * 1024

    /** Derives an AES-256 key from the pairing code and both random salts. */
    fun deriveKey(code: String, salt: ByteArray): SecretKey {
        val spec = PBEKeySpec(code.toCharArray(), salt, 30_000, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return SecretKeySpec(factory.generateSecret(spec).encoded, "AES")
    }

    fun nonce(prefix: ByteArray, counter: Long): ByteArray {
        val n = ByteArray(12)
        System.arraycopy(prefix, 0, n, 0, 4)
        ByteBuffer.wrap(n, 4, 8).putLong(counter)
        return n
    }
}

/**
 * Encrypts everything written to it in AES-256-GCM frames of up to 64 KB:
 * [4-byte length][ciphertext + 16-byte tag]. Memory use stays constant for any file size.
 */
class GcmOutputStream(
    private val out: OutputStream,
    private val key: SecretKey,
    private val noncePrefix: ByteArray
) : OutputStream() {
    private val buf = ByteArray(Crypto.CHUNK)
    private var n = 0
    private var counter = 0L
    private val cipher: Cipher = Cipher.getInstance("AES/GCM/NoPadding")

    override fun write(b: Int) {
        if (n == buf.size) flushChunk()
        buf[n++] = b.toByte()
    }

    override fun write(b: ByteArray, off: Int, len: Int) {
        var o = off
        var l = len
        while (l > 0) {
            if (n == buf.size) flushChunk()
            val c = minOf(l, buf.size - n)
            System.arraycopy(b, o, buf, n, c)
            n += c
            o += c
            l -= c
        }
    }

    override fun flush() {
        if (n > 0) flushChunk()
        out.flush()
    }

    override fun close() {
        try {
            flush()
        } finally {
            out.close()
        }
    }

    private fun flushChunk() {
        cipher.init(
            Cipher.ENCRYPT_MODE,
            key,
            GCMParameterSpec(128, Crypto.nonce(noncePrefix, counter))
        )
        val ct = cipher.doFinal(buf, 0, n)
        out.write(ByteBuffer.allocate(4).putInt(ct.size).array())
        out.write(ct)
        counter++
        n = 0
    }
}

/** Decrypts frames produced by [GcmOutputStream]. A bad tag raises [AuthException]. */
class GcmInputStream(
    private val inp: InputStream,
    private val key: SecretKey,
    private val noncePrefix: ByteArray
) : InputStream() {
    private val raw = DataInputStream(inp)
    private var cur = ByteArray(0)
    private var pos = 0
    private var counter = 0L
    private val cipher: Cipher = Cipher.getInstance("AES/GCM/NoPadding")

    private fun fill(): Boolean {
        val first = inp.read()
        if (first < 0) return false
        val len = (first shl 24) or (raw.readUnsignedByte() shl 16) or
            (raw.readUnsignedByte() shl 8) or raw.readUnsignedByte()
        if (len < 16 || len > Crypto.CHUNK + 16) throw AuthException("Invalid data frame")
        val ct = ByteArray(len)
        raw.readFully(ct)
        try {
            cipher.init(
                Cipher.DECRYPT_MODE,
                key,
                GCMParameterSpec(128, Crypto.nonce(noncePrefix, counter))
            )
            cur = cipher.doFinal(ct)
        } catch (e: GeneralSecurityException) {
            throw AuthException("Authentication failed")
        }
        pos = 0
        counter++
        return true
    }

    override fun read(): Int {
        while (pos >= cur.size) {
            if (!fill()) return -1
        }
        return cur[pos++].toInt() and 0xff
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        while (pos >= cur.size) {
            if (!fill()) return -1
        }
        val c = minOf(len, cur.size - pos)
        System.arraycopy(cur, pos, b, off, c)
        pos += c
        return c
    }

    override fun close() {
        inp.close()
    }
}
