package com.leaf.share

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.io.OutputStream

object Storage {
    class Incoming(val uri: Uri, val stream: OutputStream)

    /** Creates a new file in Downloads/LEAF through MediaStore (no storage permission needed). */
    fun openIncoming(ctx: Context, name: String): Incoming {
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LEAF")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Cannot create file in Downloads")
        val os = ctx.contentResolver.openOutputStream(uri, "w")
        if (os == null) {
            discard(ctx, uri)
            throw IOException("Cannot open file for writing")
        }
        return Incoming(uri, os)
    }

    fun commit(ctx: Context, uri: Uri) {
        val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        ctx.contentResolver.update(uri, v, null, null)
    }

    fun discard(ctx: Context, uri: Uri) {
        try {
            ctx.contentResolver.delete(uri, null, null)
        } catch (_: Exception) {
        }
    }

    fun freeBytes(): Long = try {
        StatFs(Environment.getExternalStorageDirectory().path).availableBytes
    } catch (_: Exception) {
        0L
    }

    fun totalBytes(): Long = try {
        StatFs(Environment.getExternalStorageDirectory().path).totalBytes
    } catch (_: Exception) {
        0L
    }
}

object History {
    private const val KEY = "history"
    private const val MAX = 30

    fun load(prefs: SharedPreferences): List<HistoryItem> {
        val out = ArrayList<HistoryItem>()
        try {
            val arr = JSONArray(prefs.getString(KEY, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    HistoryItem(
                        o.getString("title"),
                        o.getString("detail"),
                        o.getBoolean("out"),
                        o.getBoolean("ok"),
                        o.getLong("time")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun save(prefs: SharedPreferences, items: List<HistoryItem>) {
        val arr = JSONArray()
        for (h in items.take(MAX)) {
            arr.put(
                JSONObject()
                    .put("title", h.title)
                    .put("detail", h.detail)
                    .put("out", h.outgoing)
                    .put("ok", h.ok)
                    .put("time", h.time)
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }
}
