package com.leaf.share

import android.net.Uri

const val LEAF_PORT = 48555
const val LEAF_MAGIC = "LEAF1"

enum class Screen { HOME, SEND, RECEIVE, SETTINGS }

enum class StatusKind { IDLE, READY, BUSY, ERROR }

enum class Transport(val label: String) {
    LAN("Wi-Fi network"),
    WIFI_DIRECT("Wi-Fi Direct")
}

enum class Direction { SEND, RECEIVE }

data class Peer(
    val id: String,
    val name: String,
    val hosts: List<String>,
    val port: Int,
    val transport: Transport
)

data class OutgoingFile(val uri: Uri, val name: String, val size: Long)

data class FileMeta(val name: String, val size: Long)

data class IncomingOffer(val senderName: String, val files: List<FileMeta>) {
    val totalBytes: Long get() = files.sumOf { it.size }
}

data class TransferProgress(
    val active: Boolean = false,
    val direction: Direction = Direction.SEND,
    val peerName: String = "",
    val currentFile: String = "",
    val fileIndex: Int = 0,
    val fileCount: Int = 0,
    val doneBytes: Long = 0,
    val totalBytes: Long = 0,
    val speedBps: Double = 0.0,
    val etaSeconds: Long = -1,
    val status: String = ""
) {
    val fraction: Float
        get() = if (totalBytes <= 0) 0f else (doneBytes.toDouble() / totalBytes.toDouble()).toFloat().coerceIn(0f, 1f)
}

data class HistoryItem(
    val title: String,
    val detail: String,
    val outgoing: Boolean,
    val ok: Boolean,
    val time: Long
)

data class TransferOutcome(
    val success: Boolean,
    val message: String,
    val bytes: Long = 0,
    val avgBps: Double = 0.0,
    val names: List<String> = emptyList(),
    val authFailed: Boolean = false
)
